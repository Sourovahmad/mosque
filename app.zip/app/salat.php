<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class salat extends Model
{
    //
}
