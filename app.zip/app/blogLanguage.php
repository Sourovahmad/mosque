<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class blogLanguage extends Model
{
    use SoftDeletes;
    
}
