			<!-- Header -->
			<header id="header-area" class="header-area fixed--header sticky--header">
				<div class="container">
					<div class="header header--style-1">
						<div class="logo image--logo hidden-md hidden-sm hidden-xs">
							<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('abasas/images/logo/MMC_Title_logo-removebg-preview.png')); ?>" alt="header logo"></a>
						</div>
						<div class="header__right">
							<div class="header__right__top d-flex justify-content-end align-items-center flex-wrap flex-sm-nowrap">
								<ul class="header__right__times d-flex justify-content-end">
									<li><p><i class="icofont icofont-full-sunny"></i>SUNRISE : <span class="time-sunrise"></span></p></li>
									<li><p><i class="icofont icofont-full-night"></i>SUNSET : <span class="time-sunset"></span></p></li>
								</ul>
								
							</div>
							<div class="header__right__bottom">
								
								<!-- Main naviagtion -->
								<nav class="menu">
									<ul class="justify-content-end">
										<li class="cr-dropdown"><a href="index.html">HOME</a>
											<ul class="cr-dropdown-menu">
												<li><a href="index.html">Homepage Classic</a></li>
												<li><a href="index-boxed.html">Homepage Boxed</a></li>
												<li><a href="index-2.html">Homepage Style 2</a></li>
												<li><a href="index-slider.html">Homepage Slider</a></li>
												<li><a href="index-text-slider.html">Homepage Text Slider</a></li>
											</ul>
										</li>
										<li><a href="about-us.html">ABOUT</a></li>
										<li class="cr-dropdown"><a href="events.html">EVENT</a>
											<ul class="cr-dropdown-menu">
												<li><a href="events.html">Events</a></li>
												<li><a href="event-details.html">Event Details</a></li>
											</ul>
										</li>
										<li class="cr-dropdown"><a href="activities.html">ACTIVITIES</a>
											<ul class="cr-dropdown-menu">
												<li><a href="activities.html">Activities</a></li>
												<li><a href="single-activity.html">Single Activity</a></li>
											</ul>
										</li>
										<li><a href="donation.html">DONATION</a></li>
										<li class="cr-dropdown"><a href="#">PAGES</a>
											<ul class="cr-dropdown-menu">
												<li><a href="shop.html">Shop</a></li>
												<li><a href="shop-left-sidebar.html">Shop Left Sidebar</a></li>
												<li><a href="shop-right-sidebar.html">Shop Right Sidebar</a></li>
												<li><a href="product-details.html">Product Details</a></li>
												<li><a href="cart.html">Shopping Cart</a></li>
												<li><a href="wishlist.html">Wishlist</a></li>
												<li><a href="checkout.html">Checkout</a></li>
											</ul>
										</li>
										<li class="cr-dropdown"><a href="blogs-right-sidebar.html">BLOG</a>
											<ul class="cr-dropdown-menu">
												<li><a href="blogs.html">Blogs</a></li>
												<li><a href="blogs-right-sidebar.html">Blogs Right Sidebar</a></li>
												<li><a href="blogs-left-sidebar.html">Blogs Left Sidebar</a></li>
												<li><a href="blog-details.html">Blog Details</a></li>
												<li><a href="blog-details-left-sidebar.html">Blog Details Left Sidebar</a></li>
											</ul>
										</li>
										<li><a href="contact.html">Contact</a></li>
									</ul>
								</nav><!-- //Main naviagtion -->                                                                            

							</div>
						</div>
						<div class="mobile-menu hidden-lg hidden-xlg hidden-xx hidden-sp">
							<a class="mobile-logo" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('abasas/images/logo/MMC_Title_logo-removebg-preview.png')); ?>" alt="logo"></a>
						</div>
					</div>
				</div>
			</header><?php /**PATH D:\project\mosque\resources\views/includes/nav2.blade.php ENDPATH**/ ?>