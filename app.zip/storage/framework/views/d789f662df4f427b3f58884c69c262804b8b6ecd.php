  <!-- Footer -->
  <footer class="sticky-footer bg-abasas-dark">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright &copy; Abasas Technologies 2012 - <?php echo e(now()->format("Y")); ?></span>
      </div>
    </div>
   </footer>
  <!-- End of Footer --><?php /**PATH D:\project\mosque\resources\views/components/footer.blade.php ENDPATH**/ ?>