				
			
			
			
			
			<!-- Header -->
			<header id="header-area" class="header-area fixed--header sticky--header">
				<div class="container">
					<div class="header header--style-1">
						<div class="logo image--logo hidden-md hidden-sm hidden-xs">
							<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('abasas/images/logo/MMC_Title_logo-removebg-preview.png')); ?>" alt="header logo"></a>
						</div>
						<div class="header__right">
							<div class="header__right__top d-flex justify-content-end align-items-center flex-wrap flex-sm-nowrap">
								<ul class="header__right__times d-flex justify-content-end">
									<li><p><i class="icofont icofont-full-sunny"></i>SUNRISE : <span class="time-sunrise"></span></p></li>
									<li><p><i class="icofont icofont-full-night"></i>SUNSET : <span class="time-sunset"></span></p></li>
								</ul>
								
							</div>
							<div class="header__right__bottom">
								
								<!-- Main naviagtion -->
								<nav class="menu">
									<ul class="justify-content-end">
										
										<li><a href="<?php echo e(route('home')); ?>">HOME</a></li>

										
										<li class="cr-dropdown"><a href="<?php echo e(route('about.index')); ?>">About</a>
											<ul class="cr-dropdown-menu">
												<li><a href="<?php echo e(route('about.index')); ?>/#imam">Imam</a></li>
												<li><a href="<?php echo e(route('about.index')); ?>/#gallery">Gallery</a></li>
												
											</ul>
										</li>
										
										<li class="cr-dropdown"><a href="activities.html">MMC members</a>
											<ul class="cr-dropdown-menu">
												<li><a href="">Life Members</a></li>
												<li><a href="">General Members</a></li>
												<li><a href="">Executive Committee</a></li>
												
											</ul>
										</li>
										<li><a href="<?php echo e(route('events')); ?>">EVENT</a></li>
										<li><a href="<?php echo e(route('donations.index')); ?>">DONATION</a></li>

										<li class="cr-dropdown"><a href="">OUR PROGRAMS</a>
											<ul class="cr-dropdown-menu">
												<li><a href="">Jummah Kutba</a></li>
												<li><a href="">Darse Bujhari</a></li>
												<li><a href="">Darse Quran</a></li>
												<li><a href="">Special Event</a></li>
											</ul>
										</li>
										
										<li><a target="_blank" href="<?php echo e(asset('abasas/images/prayingTimes.jpg')); ?>">Praying Times</a></li>
										<li><a href="">Blog</a></li>
									
									</ul>
								</nav><!-- //Main naviagtion -->                                                                            

							</div>
						</div>
						<div class="mobile-menu hidden-lg hidden-xlg hidden-xx hidden-sp">
							<a class="mobile-logo" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('abasas/images/logo/MMC_Title_logo-removebg-preview.png')); ?>" alt="logo"></a>
						</div>
					</div>
				</div>
			</header><?php /**PATH D:\project\mosque\resources\views/includes/nav.blade.php ENDPATH**/ ?>