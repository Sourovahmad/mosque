

<?php $__env->startSection('content'); ?>




 <?php if (isset($component)) { $__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DataTable::class, ['dataArray' => $dataArray]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0)): ?>
<?php $component = $__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0; ?>
<?php unset($__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\mosque\resources\views/admin/blog/category.blade.php ENDPATH**/ ?>