

<?php $__env->startSection('Breadcrumb'); ?>
<!-- //Breadcrumb area -->
<!-- Top Banner -->
<div class="banner-area">
    <div class="banner bg-image--7 banner-text-slide slider-arrow--style1 slide-animate-text">

        <!-- Single Banner -->
        <div class="banner__single fullscreen d-flex align-items-center" data-black-overlay="6">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="banner__content text-center">
                            
<h1>Events</h1>
                            

                            
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- //Single Banner -->


    </div>
</div><!-- //Top Banner -->




<!-- //Top Banner -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- Page Conent -->
<main class="page-content">

    <div class="events-grid ptb--150 bg--white">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="events2">


                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <!-- Event Single -->
                        <article class="event-single wow fadeInRight">
                            <div class="event-single__thumb">
                                <a href="<?php echo e(route('event-single', $event->id)); ?>">
                                    <img src="<?php echo e(asset($event->image->thumbnail)); ?>" alt="event thumb">
                                </a>
                                <div class="event-single__date">

                                    <h3><?php echo e(Carbon\Carbon::parse( $event->date )->format('d F, Y')); ?></h3>
                                </div>
                            </div>
                            <div class="event-single__content">
                                <h3><a href="<?php echo e(route('event-single', $event->id)); ?>"><?php echo e($event->title); ?></a></h3>
                                <p><?php echo substr($event->description, 0,50) ?> </p>
                                <div class="event-single__content__location">
                                    <p><i class="icofont icofont-institution"></i><?php echo e($event->vanu); ?></p>
                                    <p><i class="icofont icofont-wall-clock"></i>
                                      
                                </div>
                            </div>
                        </article>
                        <!-- //Event Single -->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    </div>
                    <div class="cr-pagination text-right">
                        <ul>
                            <?php echo e($events->links()); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

</main><!-- //Page Conent -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\mosque\resources\views/events/index.blade.php ENDPATH**/ ?>