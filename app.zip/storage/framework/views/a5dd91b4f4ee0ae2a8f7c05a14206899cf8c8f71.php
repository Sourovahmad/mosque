


<?php $__env->startSection('content'); ?>


<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php if(is_array(session('success'))): ?>
        <ul>
            <?php $__currentLoopData = session('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <?php echo e(session('success')); ?>

    <?php endif; ?>
</div>
<?php endif; ?>



<div class="card shadow mb-4">

    <div class="card-header py-3 bg-abasas-dark">
        <nav class="navbar  ">

            <div class="navbar-brand"><span id="eventList"> Salat Time</span> </div>

        </nav>
    </div>

    <div class="card-body">

        <form method="POST" id="createEventForm" action="<?php echo e(route('admin.salat.update',$salat->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="row">
                <div class="form-group col-md-4 col-sm-12 p-4">
                    <label for="fajr"> Fajr </label>
                    <input type="time" name="fajr" class="form-control" id="fajr" value="<?php echo e($salat->fajr); ?>" required>
                </div>

                <div class="form-group col-md-4 col-sm-12 p-4">
                    <label for="dhuhr">Dhuhr</label>
                    <input type="time" name="dhuhr" class="form-control" id="dhuhr" value="<?php echo e($salat->dhuhr); ?>"required>
                </div>

                <div class="form-group col-md-4 col-sm-12 p-4">
                    <label for="jumma"> Jumma</label>
                    <input type="time" name="jumma" class="form-control" id="jumma" value="<?php echo e($salat->jumma); ?>"required>
                </div>

                <div class="form-group col-md-4 col-sm-12 p-4">
                    <label for="asr"> Asr</label>
                    <input type="time" name="asr" class="form-control" id="asr" value="<?php echo e($salat->asr); ?>" required>
                </div>

                <div class="form-group col-md-4 col-sm-12 p-4">
                    <label for="maghrib"> Maghrib</label>
                    <input type="time" name="maghrib" class="form-control" id="maghrib" value="<?php echo e($salat->maghrib); ?>" required>
                </div>

                <div class="form-group col-md-4 col-sm-12 p-4">
                    <label for="isha">Isha</label>
                    <input type="time" name="isha" class="form-control" id="isha" value="<?php echo e($salat->isha); ?>" required>
                </div>


            </div>

            <button type="submit" id="createEventSubmit" class="btn bg-abasas-dark"> Update</button>







        </form>

    </div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\mosque\resources\views/admin/salat/index.blade.php ENDPATH**/ ?>