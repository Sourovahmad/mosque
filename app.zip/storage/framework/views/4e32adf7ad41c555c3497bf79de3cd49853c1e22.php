


<?php $__env->startSection('content'); ?>


<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php if(is_array(session('success'))): ?>
    <ul>
        <?php $__currentLoopData = session('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php else: ?>
    <?php echo e(session('success')); ?>

    <?php endif; ?>
</div>
<?php endif; ?>



<div class="card shadow mb-4">

    <div class="card-header py-3 bg-abasas-dark">
        <nav class="navbar  ">

            <div class="navbar-brand"><span id="eventList"> Imam Information</span> </div>

        </nav>
    </div>

    <div class="card-body">
        <div class="row">
            <div class="col-md-6 col-sm-12 p-4">
                <div class="card" style="width: 18rem;">
                    <img class="card-img-top" src="<?php echo e(asset($imam->image->url)); ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title text-center"><?php echo e($imam->name); ?></h5>
                    </div>

                </div>




                
            </div>
            <div class="col-md-6 col-sm-12 p-4">

                <form method="POST" id="createEventForm" action="<?php echo e(route('admin.imam.update',$imam->id )); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>

                    <div class="row">
                        
                    <div class="form-group col-12  ">
                        <label for="image">Upload image</label><br>
                        <input type="file" name="image" id="image" accept=".jpg, .jpeg" >
                    </div>
                    
                    <div class="form-group col-12  ">
                        <label for="name"> Name<span style="color: red"> *</span></label>
                        <input type="text" name="name" class="form-control" id="name" value="<?php echo e($imam->name); ?>"  required>
                    </div>


                    </div>

                    <button type="submit" id="createEventSubmit" class="btn bg-abasas-dark"> Update</button>







                </form>
            </div>

        </div>


    </div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\mosque\resources\views/admin/imam/index.blade.php ENDPATH**/ ?>