
<?php $__env->startSection('content'); ?>



<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php if(is_array(session('success'))): ?>
        <ul>
            <?php $__currentLoopData = session('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <?php echo e(session('success')); ?>

    <?php endif; ?>
</div>
<?php endif; ?>


<div class="card shadow mb-4">

    <div class="card-header py-3 bg-abasas-dark">
        <nav class="navbar  ">

            <div class="navbar-brand"><span id="eventList"> Program List</span> </div>

            <a href="<?php echo e(route('admin.programs.create')); ?>"><button type="button" class="btn btn-success btn-lg"
                    id="AddNewFormButton"><i class="fas fa-plus" id="PlusButton"></i></button></a>


        </nav>
    </div>
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead class="bg-abasas-dark">

                    <tr>

                        <th> #</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Action</th>

                    </tr>
                </thead>
                <tfoot class="bg-abasas-dark">
                    <tr>

                        <th> #</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Action</th>

                    </tr>

                </tfoot>

                <tbody>

                    <?php
                    $itr=1;
                    ?>
                    <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr class="data-row">
                        <td class="iteration"><?php echo e($itr++); ?></td>
                        <td class="word-break"><?php echo e($program->title); ?></td>
                        <td class="word-break"><?php echo e($program->category->name); ?></td>


                        <td class="align-middle">
                            <a href="<?php echo e(route('admin.programs.edit',$program->id)); ?>"><button title="Edit" type="button"
                                    class="dataEditItemClass btn btn-success btn-sm" id="data-edit-button"> <i
                                        class="fa fa-edit" aria-hidden="false"> </i></button></a>


                            <form method="POST" action="<?php echo e(route('admin.programs.destroy',$program->id)); ?>"
                                id="delete-form-<?php echo e($program->id); ?>" style="display:none; ">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field("delete")); ?>

                            </form>




                            <button title="Delete" class="dataDeleteItemClass btn btn-danger btn-sm" onclick="if(confirm('are you sure to delete this')){
				document.getElementById('delete-form-<?php echo e($program->id); ?>').submit();
			}
			else{
				event.preventDefault();
			}
			" class="btn btn-danger btn-sm btn-raised">
                                <i class="fa fa-trash" aria-hidden="false">

                                </i>
                            </button>




                        </td>


                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>


            </table>
        </div>
    </div>
</div>


<script>
    $(document).ready(function(){
        
        $('#dataTable').DataTable({   
                    dom: 'lBfrtip',
                    buttons: [
                        'copy', 'csv', 'excel' , 'pdf' , 'print'
                    ]
                });
     
    });
</script>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\mosque\resources\views/admin/program/index.blade.php ENDPATH**/ ?>