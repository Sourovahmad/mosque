

<?php $__env->startSection('Breadcrumb'); ?>
    <!-- Top Banner -->

    
    <!-- //Breadcrumb area -->
<!-- Top Banner -->
<div class="banner-area">
    <div class="banner bg-image--7 banner-text-slide slider-arrow--style1 slide-animate-text">

        <!-- Single Banner -->
        <div class="banner__single fullscreen d-flex align-items-center" data-black-overlay="6">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="banner__content text-center">
                            

<h1 >Event Details</h1>
<div class="cr-breadcrumb__tree text-left text-md-left text-center">
    <ul>
        <li><a href="<?php echo e(route('home')); ?>">Events</a></li>
        <li><?php echo e($event->title); ?></li>
    </ul>
</div>
                            

                            
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- //Single Banner -->


    </div>
</div><!-- //Top Banner -->


    <!-- //Top Banner -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <!-- Page Conent -->
    <main class="page-content">

        <!-- Event Details Area -->
        <div class="event-details-area ptb--150 bg--white">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-xl-9">
                        <div class="event-details">
                            <div class="event-details__thumb">
                                <img src="<?php echo e(asset($event->image->url)); ?>" alt="Single event Details" style="width: 100%">
                            </div>
                            <h2 class="event-details__title"><?php echo e($event->title); ?></h2>
                            <div class="event-details__meta">
                                <ul>
                                    <li><span>Date:</span> <?php echo e(Carbon\Carbon::parse($event->date)->format('d F, Y')); ?></li>
                                    <li><span>Vanu :</span> <?php echo e($event->vanu); ?></li>
                                    <li><span>Time :</span><?php echo e(Carbon\Carbon::parse($event->start_time)->format('h:i:a')); ?> -
                                        <?php echo e(Carbon\Carbon::parse($event->end_time)->format('h:i:a')); ?></li>
                                </ul>
                            </div>
                            <div class="event-details__content">

                                <p><?php echo($event->description) ?></p>

                            </div>

                            <div class="event-details__footer d-flex justify-content-between align-items-center flex-wrap">
                                <div class="social-icons social-icons--rounded">
                                    <ul>
                                        <li class="facebook"><a href="https://www.facebook.com/"><i
                                                    class="fa fa-facebook"></i></a></li>
                                        <li class="twitter"><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
                                        </li>
                                        <li class="instagram"><a href="https://www.instagram.com/"><i
                                                    class="fa fa-instagram"></i></a></li>
                                        <li class="google-plus"><a href="https://plus.google.com/"><i
                                                    class="fa fa-google-plus"></i></a></li>
                                    </ul>
                                </div>
                               
                            </div>

                        </div>
                    </div>

                    <!-- Sidebar Widgets Area -->
                    <div class="col-lg-4 col-xl-3">
                        <!-- Sidebar Widgets -->
                        <div class="sidebar widgets">


                            <!-- Single Widget (Recentpost) -->
                            <div class="single-widget wgt-recentpost">
                                <h4 class="widget-title">Recent Event</h4>

                                <ul>
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                            
                                    <li>
                                        <div class="wgt-recentpost__thumb">
                                            <a href="<?php echo e(route('event-single', $event->id)); ?>">
                                                <img src="<?php echo e(asset($event->image->thumbnail)); ?>" alt="event thumb">
                                            </a>
                                        </div>
                                        <div class="wgt-recentpost__content">
                                            <h5><a href="<?php echo e(route('event-single', $event->id)); ?>"><?php echo e($event->title); ?></a></h5>
                                            <p><span><?php echo e($event->vanue); ?></span><span><?php echo e(Carbon\Carbon::parse($event->date)->format('d F, Y')); ?></span></p>
                                        </div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div><!-- Single Widget (Recentpost) -->
                        </div><!-- //Sidebar Widgets  -->
                    </div><!-- //Sidebar Widgets Area -->

                </div>
            </div>
        </div><!-- //Event Details Area -->

    </main><!-- //Page Conent -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\mosque\resources\views/events/event-details.blade.php ENDPATH**/ ?>