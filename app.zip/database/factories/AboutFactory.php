<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\about;
use Faker\Generator as Faker;

$factory->define(about::class, function (Faker $faker) {
    return [
        //
    ];
});
