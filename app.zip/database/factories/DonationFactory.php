<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\donation;
use Faker\Generator as Faker;

$factory->define(donation::class, function (Faker $faker) {
    return [
        //
    ];
});
