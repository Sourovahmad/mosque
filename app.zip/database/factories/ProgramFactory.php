<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\program;
use Faker\Generator as Faker;

$factory->define(program::class, function (Faker $faker) {
    return [
        //
    ];
});
