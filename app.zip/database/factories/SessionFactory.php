<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\session;
use Faker\Generator as Faker;

$factory->define(session::class, function (Faker $faker) {
    return [
        //
    ];
});
