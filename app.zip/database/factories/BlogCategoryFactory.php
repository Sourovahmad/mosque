<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\blogCategory;
use Faker\Generator as Faker;

$factory->define(blogCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
