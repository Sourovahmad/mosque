<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\salat;
use Faker\Generator as Faker;

$factory->define(salat::class, function (Faker $faker) {
    return [
        //
    ];
});
