<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\imam;
use Faker\Generator as Faker;

$factory->define(imam::class, function (Faker $faker) {
    return [
        //
    ];
});
