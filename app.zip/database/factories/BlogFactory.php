<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\blog;
use Faker\Generator as Faker;

$factory->define(blog::class, function (Faker $faker) {
    return [
        //
    ];
});
