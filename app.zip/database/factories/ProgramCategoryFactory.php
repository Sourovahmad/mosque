<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\programCategory;
use Faker\Generator as Faker;

$factory->define(programCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
