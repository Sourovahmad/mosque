<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\committee;
use Faker\Generator as Faker;

$factory->define(committee::class, function (Faker $faker) {
    return [
        //
    ];
});
