<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\eventCategory;
use Faker\Generator as Faker;

$factory->define(eventCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
