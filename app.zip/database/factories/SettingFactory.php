<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\setting;
use Faker\Generator as Faker;

$factory->define(setting::class, function (Faker $faker) {
    return [
        //
    ];
});
