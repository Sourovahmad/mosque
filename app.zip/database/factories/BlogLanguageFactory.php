<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\blogLanguage;
use Faker\Generator as Faker;

$factory->define(blogLanguage::class, function (Faker $faker) {
    return [
        //
    ];
});
