
@extends('admin.includes.app')
@section('content')




<x-data-table
:dataArray="$dataArray"

/>


 
@endsection