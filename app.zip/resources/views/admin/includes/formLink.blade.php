<input type="text"  id="homeRoute" value="{{route('home')}}" hidden> 
<input type="text" id="csrfToken"  value="{{ csrf_token() }}"  hidden>